Name: Eric Pham
UID:  303 787 024

This directory contains the files for hw2.

  hw2question1.txt: the answer for the question in the first  section
  hw2a.c:           the source code for first  part of second section
  hw2b.c:           the source code for second part of second section
  hw2c.c:           the source code for third  part of second section
  hw2answers.txt:   responses for questions in the third section (related to section 2)